clc;clear; close all;

% runtime: ~5 minutes (if the pre-built pdf is loaded)

% Activate Line#94 of 'figure33.m' and run it to create the required PDF
% The generated file 'rndDomain_density.mat' will be loaded in 
% the current script.
% The file size is roughly 30 MB.


% Load dataset
rndDataBase = load('rndDomain_density.mat');
data=rndDataBase.data;
% density sub-domain
x0=0.3;y0=0.3;
r0=.1;


N=350;
nFixed=90;

XY=load( 'domain_notSorted.txt');
[X,Y]=sortDomainBoundary(XY);

X=[X;X(1);];
Y=[Y;Y(1);];

S=zeros(size(X));
S(2:end)=sqrt( (X(2:end)-X(1:end-1)).^2 + (Y(2:end)-Y(1:end-1)).^2);

S=cumsum(S');
S=S./max(S);
XY=[X';Y'];
pp = spline(S,XY);
xy = ppval(pp, linspace(0,1,1001));

Xb=xy(1,:)';
Yb=xy(2,:)';

sBoundaryNodes=linspace(0,1,nFixed+1);
sBoundaryNodes=sBoundaryNodes(2:end);

XY_bN=ppval(pp, sBoundaryNodes);


figure(1)
clf;
fill(Xb,Yb,'y'),xlabel('X'),ylabel('Y');
hold on;
scatter(XY_bN(1,:),XY_bN(2,:),30,'ko','filled')
xlabel('X')
ylabel('Y')
xlim([0,1])
ylim([0,1])


global sigma;
global nUpdated;
nUpdated=4*round(sqrt(N));
sigma =.0002;
g_t=0.9;

thresh=0.021;


Ktot=size(data,1);
Ktot=900000;
indx=randi(Ktot,N,1);

X=data(indx,1);
Y=data(indx,2);

scatter(X,Y,20,'ro','filled')


X=[X;XY_bN(1,:)'];
Y=[Y;XY_bN(2,:)'];



for k=1:Ktot

 
            xg=data(k,1);yg=data(k,2);
          
            [xW,yW,indxVec]= findWinners(X,Y,xg,yg);

            for i=1:nUpdated

              f_ij = calcLateralCoeff([xW(1),yW(1)],[xW(i),yW(i)]);
              
              
              if indxVec(i)<=N
                  X(indxVec(i))= X(indxVec(i)) + g_t*f_ij*(xg-X(indxVec(i)));
                  Y(indxVec(i))= Y(indxVec(i)) + g_t*f_ij*(yg-Y(indxVec(i)));
              

                %   scatter(X(indxVec(i)),Y(indxVec(i)),'sk')
                
                if (xg-x0)^2+(yg-y0)^2 <= r0^2 || ...
                        (X(indxVec(1))-x0)^2+(Y(indxVec(1))-y0)^2 <= r0^2  ...
%                         || (X(indxVec(1))-x0)^2+(Y(indxVec(1))-y0)^2 <= r0^2
                    
                    threshEffective=thresh/3;
                else
                    threshEffective=thresh;
                end

                if i>1  % repel too-close neurons
                    d=sqrt((X(indxVec(1))-X(indxVec(i)))^2+ ...
                        (Y(indxVec(1))-Y(indxVec(i)))^2);

                    if d <threshEffective
                        X(indxVec(i)) = X(indxVec(i)) + ...
                            threshEffective/d*(X(indxVec(i))-X(indxVec(1)));

                        Y(indxVec(i)) = Y(indxVec(i)) + ...
                            threshEffective/d*(Y(indxVec(i))-Y(indxVec(1)));

                    end

                end
            
            
              end

            end
            

    if mod(k,100)==0
        g_t=0.9997*g_t;
    end
    
    if mod(k,10000)==0
        k
    end
    
    
end


% Remove points outside the domain:
Xin=X(1:N);
Yin=Y(1:N);
Xb=X(N+1:end);
Yb=Y(N+1:end);
isInside=checkInsideOrOutside(Xb,Yb,Xin,Yin);

Xin=Xin(isInside);
Yin=Yin(isInside);

for i=1:nFixed
   j=1;
   while j <=length(Xin)
       Dij=sqrt((Xin(j)-Xb(i))^2+(Yin(j)-Yb(i))^2);
       if Dij < thresh
           Xin(j)=[];
           Yin(j)=[];
       end   
       j=j+1;
   end

end
%%
i=1;
while i <=length(Xin)
    j=i+1;
    
    while j<=length(Xin)
        
        if (Xin(i)-x0)^2+(Yin(i)-y0)^2 <= r0^2 ||...
           (Xin(j)-x0)^2+(Yin(j)-y0)^2 <= r0^2
       
            threshEffective=thresh;
        else
            threshEffective=thresh;
        end
        
        
        Dij=sqrt((Xin(i)-Xin(j))^2+(Yin(i)-Yin(j))^2);
        if Dij < threshEffective
            Xin(j)=[];
            Yin(j)=[];
        end
        j=j+1;
    end
    
    i=i+1;
end

X=[Xin;Xb];
Y=[Yin;Yb];

        
figure(2)
clf;
fill(Xb,Yb,'y'),xlabel('X'),ylabel('Y');
hold on;
scatter(X,Y,'bo','filled');
xlim([0,1]);
ylim([0,1]);


DT = delaunay(X,Y);
L=length(X);

i=1;


while i<=length(DT)
    k=L-nFixed+1;

    if DT(i,1)>=k && DT(i,2)>=k && DT(i,3)>=k
        DT(i,:)=[];
    else
        i=i+1; 
    end
end

triplot(DT,X,Y,'k');

toc;


%%
% figure(3)
% clf;
% x=[0.1,0.9,0.9,0.1]';
% y=[0.1,0.1,0.9,0.9]';
% for i=1:4
%     text(x(i),y(i),num2str(i))
% end
% hold on;
% DT = delaunay(x,y);
% triplot(DT,x,y);
% xlim([0,1]);
% ylim([0,1]);
% DT


function [xW,yW,indxVec]= findWinners(X,Y,xg,yg)
    global nUpdated;
    
    r = (X-xg).^2 + (Y-yg).^2;
    
    [sorted,indxVec]=sort(r);
    
    xW=X(indxVec(1:nUpdated));
    yW=Y(indxVec(1:nUpdated));
end

function f = calcLateralCoeff(X0,X)
    
    global sigma;
    f = NaN (size(X,1));
    for i=1: length(f)
        f(i) = exp(-0.5*norm((X(i,:)-X0))^2/sigma);
    end

end

function [X,Y]=sortDomainBoundary(XY_in)
    Xin=XY_in(:,1);
    Yin=XY_in(:,2);
    
    X=NaN(size(Xin));
    Y=NaN(size(Xin));
    
    X(1)=Xin(1);
    Y(1)=Yin(1);

    Xin(1)=[];
    Yin(1)=[];

    i=1;

    while ~isempty(Xin)>0
        d=sqrt( (Xin-X(i)).^2 + (Yin-Y(i)).^2  );
        [~,indx]=min(d);

        X(i+1)=Xin(indx);
        Y(i+1)=Yin(indx);
        Xin(indx)=[];
        Yin(indx)=[];

        i=i+1;
    end
    
end

function isInside=checkInsideOrOutside(Xb,Yb,xp,yp)
    isInside=true(size(xp));
    for j=1:length(xp)
        t=0;
        for i=1:length(Xb)
            v1=[Xb(i)-xp(j),Yb(i)-yp(j)];
            if i<length(Xb)
                v2=[Xb(i+1)-xp(j),Yb(i+1)-yp(j)];
            else
                v2=[Xb(1)-xp(j),Yb(1)-yp(j)];
            end

            t= t+ (v1(1)*v2(2)-v1(2)*v2(1))/(norm(v1)*norm(v2));
        end


        if abs(t-2*pi)<abs(t)
            isInside(j)=true;
        else
            isInside(j)=false;
        end
        if mod(j,10000)==0
            j
        end
    end
        

end

