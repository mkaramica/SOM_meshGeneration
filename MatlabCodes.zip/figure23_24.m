clc;clear;
dx=0.01;
x=0:0.01:2;
pdf=NaN(size(x));
pdf(x<=0.5)=1;
pdf(x>0.5 & x<=1)=0;
pdf(x>1 & x<=1.5)=0.5+2*(x(x>1 & x<=1.5)-1);
pdf(x>1.5)=0.5;
% pdf=1+0*x;
pdf=pdf./sum(pdf)/dx;

figure(1)
clf;
plot(x,pdf,'b','linewidth',2)
xlabel('X')
ylabel('PDF')
ylim([0,1.5])
hold on;
plot([0,2],[max(pdf),max(pdf)],'r--','linewidth',2)

k=1000000;

X=randomGen(x,pdf,k);

figure(2)
clf;
histogram(X,length(x))
xlim([0,2])
xlabel('X')
ylabel('PDF')
title('Histogram for Rejection Method')


function xVec=randomGen(xRange,pdf,N)

    yMax=max(pdf);
    if nargin==2
        N=1;
    end
     
    xVec=NaN(N,1);
        
    i_x=0;
    
    while i_x < N
        r1=rand;
        r2=rand;
        
        x=xRange(1)+r1*(xRange(end)-xRange(1));
        indx=find(xRange>x,1);
        yPDF=pdf(indx-1)+...
        (x-xRange(indx-1))/(xRange(indx)-xRange(indx-1))*(pdf(indx)-pdf(indx-1));
        
        yRand=r2*yMax;
        
        if yRand <= yPDF
            i_x=i_x+1;
            xVec(i_x)=x;
        end
    end

end

