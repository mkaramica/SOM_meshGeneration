clc;clear; clf;

nBoundaryNodes=60;



XY=load( 'domain_notSorted.txt');
[X,Y]=sortDomainBoundary(XY);

X=[X;X(1);];
Y=[Y;Y(1);];

S=zeros(size(X));
S(2:end)=sqrt( (X(2:end)-X(1:end-1)).^2 + (Y(2:end)-Y(1:end-1)).^2);

S=cumsum(S');
S=S./max(S);
XY=[X';Y'];
pp = spline(S,XY);
xy = ppval(pp, linspace(0,1,1001));

Xb=xy(1,:)';
Yb=xy(2,:)';

sBoundaryNodes=linspace(0,1,nBoundaryNodes+1);
sBoundaryNodes=sBoundaryNodes(2:end);

XY_bN=ppval(pp, sBoundaryNodes);




xp=rand(100,1);
yp=rand(100,1);

isInside=checkInsideOrOutside(Xb,Yb,xp,yp);
figure(1)
clf;
fill(Xb,Yb,'y'),xlabel('X'),ylabel('Y');
hold on;
plot(X,Y,'-k','linewidth',2);
scatter(xp(isInside),yp(isInside),50,'bo','filled')
scatter(xp(~isInside),yp(~isInside),50,'ro','filled')
xlim([0,1]);
ylim([0,1]);



function isInside=checkInsideOrOutside(Xb,Yb,xp,yp)
    isInside=true(size(xp));
    for j=1:length(xp)
        t=0;
        for i=1:length(Xb)
            v1=[Xb(i)-xp(j),Yb(i)-yp(j)];
            if i<length(Xb)
                v2=[Xb(i+1)-xp(j),Yb(i+1)-yp(j)];
            else
                v2=[Xb(1)-xp(j),Yb(1)-yp(j)];
            end

            t= t+ (v1(1)*v2(2)-v1(2)*v2(1))/(norm(v1)*norm(v2));
        end


        if abs(t-2*pi)<abs(t)
            isInside(j)=true;
        else
            isInside(j)=false;
        end
        if mod(j,10000)==0
            j
        end
    end
        

end

function [X,Y]=sortDomainBoundary(XY_in)
    Xin=XY_in(:,1);
    Yin=XY_in(:,2);
    
    X=NaN(size(Xin));
    Y=NaN(size(Xin));
    
    X(1)=Xin(1);
    Y(1)=Yin(1);

    Xin(1)=[];
    Yin(1)=[];

    i=1;

    while ~isempty(Xin)>0
        d=sqrt( (Xin-X(i)).^2 + (Yin-Y(i)).^2  );
        [~,indx]=min(d);

        X(i+1)=Xin(indx);
        Y(i+1)=Yin(indx);
        Xin(indx)=[];
        Yin(indx)=[];

        i=i+1;
    end
    
end
