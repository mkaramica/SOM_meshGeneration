clc;clear; clf;

% runtime: ~65 sec

global sigma;
global nUpdated;
N=250;
nFixed=13;
nUpdated=3*round(sqrt(N));
sigma =.0002;
g_t=0.8;

thresh=0.02;

X = rand(N,1);
Y = rand(N,1);


xF1=zeros(nFixed,1);
yF1=linspace(0,1,nFixed)';

xF2=linspace(1/nFixed,1,nFixed-1)';
yF2=ones(nFixed-1,1);

xF3=ones(nFixed-1,1);
yF3=linspace(1-1/nFixed,0,nFixed-1)';

xF4=linspace(1-1/nFixed,0,nFixed-1)';
yF4=zeros(nFixed-1,1);

X=[X;xF1;xF2;xF3;xF4];
Y=[Y;yF1;yF2;yF3;yF4];


for k=1:300000

 
            xg=rand;yg=rand;
          
            [xW,yW,indxVec]= findWinners(X,Y,xg,yg);

            for i=1:nUpdated

              f_ij = calcLateralCoeff([xW(1),yW(1)],[xW(i),yW(i)]);
              
              
              if indxVec(i)<=N
                  X(indxVec(i))= X(indxVec(i)) + g_t*f_ij*(xg-X(indxVec(i)));
                  Y(indxVec(i))= Y(indxVec(i)) + g_t*f_ij*(yg-Y(indxVec(i)));
              

                %   scatter(X(indxVec(i)),Y(indxVec(i)),'sk')

                if i>1  % repel too-close neurons
                    d=sqrt((X(indxVec(1))-X(indxVec(i)))^2+ ...
                        (Y(indxVec(1))-Y(indxVec(i)))^2);

                    if d <thresh
                        X(indxVec(i)) = X(indxVec(i)) + ...
                            thresh/d*(X(indxVec(i))-X(indxVec(1)));

                        Y(indxVec(i)) = Y(indxVec(i)) + ...
                            thresh/d*(Y(indxVec(i))-Y(indxVec(1)));

                    end

                end
            
            
              end

            end
            
            
            
            
            

    if mod(k,100)==0
        g_t=0.999*g_t;
    end
end

i=1;
while i <=length(X)
    j=i+1;
    while j<=length(X)
        Dij=sqrt((X(i)-X(j))^2+(Y(i)-Y(j))^2);
        if (i~=j) && Dij < thresh
            X(j)=[];
            Y(j)=[];
        end
        j=j+1;
    end
    
    i=i+1;
end
        
 %%       
Xadd=[0,0,1,1]';
Yadd=[0,1,1,0]';

DijAVG=0;
n=0;
for i=1:length(X)
    Dlist=sort(sqrt((X(i)-X).^2+(Y(i)-Y).^2))
    DijAVG=DijAVG + Dlist(2)+Dlist(3)+Dlist(4);
end

DijAVG=DijAVG/(3*length(X))





% X=[X;Xadd];
% Y=[Y;Yadd];
%%
Xb=[0,0,1,1];
Yb=[0,1,1,0];
hold on
for i=1:3
    plot([Xb(i),Xb(i+1)],[Yb(i),Yb(i+1)],'r','linewidth',2)
end
plot([Xb(4),Xb(1)],[Yb(4),Yb(1)],'r','linewidth',2)

scatter(Xb,Yb,100,'ok','filled')


scatter(X,Y,'g*');
xlabel('x')
ylabel('y')
xlim([-0.1,1.1]);
ylim([-0.1,1.1]);


DT = delaunay(X,Y);
figure(1);

triplot(DT,X,Y);


function [xW,yW,indxVec]= findWinners(X,Y,xg,yg)
    global nUpdated;
    
    r = (X-xg).^2 + (Y-yg).^2;
    
    [sorted,indxVec]=sort(r);
    
    xW=X(indxVec(1:nUpdated));
    yW=Y(indxVec(1:nUpdated));
end


function f = calcLateralCoeff(X0,X)
    
    global sigma;
    f = NaN (size(X,1));
    for i=1: length(f)
        f(i) = exp(-0.5*norm((X(i,:)-X0))^2/sigma);
    end

end





