clc;clear;clf;
k=1e6; % Number of samples

a=2;    % Probability Ratio of the zoomed region to the rest of the domain;
p=0.4;  % start of step
q=0.6;  % End of step


Atot=1+(q-p)*(a-1);


x1=p/Atot;
x2=x1+a*(q-p)/Atot;
x3=x2+(1-q)/Atot;


X=NaN(k,1);

for i=1:k
    r=rand;
    
    if r<x1
        X(i)=r*p/x1;
    elseif r<x2
        X(i)=p+(r-x1)*(q-p)/(x2-x1);
    else
        X(i)=q+(r-x2)*(1-q)/(1-x2);
    end
 
end




histogram(X,100);
xlabel('X')
ylabel('Counter')


