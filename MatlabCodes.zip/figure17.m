clc;clear; clf;
global sigma;
global nUpdated;

ss=rng;

x1=0.1;x2=0.7;x3=0.35;
y1=0.3;y2=0.2;y3=0.9;
domainArea = 0.5 *(-y2*x3 + y1*(-x2 + x3) + x1*(y2 - y3) + x2*y3);
% x1=0.0;x2=1;x3=0.5;
% y1=0.0;y2=0.0;y3=sqrt(3)/2;


TriX=[x1,x2,x3];
TriY=[y1,y2,y3];


N=180;
nFixedtotal=45;
nUpdated=3*round(sqrt(N));
sigma =.0002;
g_t=0.8;

thresh=0.01;
threshRepel=thresh;


L1=sqrt((x1-x2)^2+(y1-y2)^2);
L2=sqrt((x2-x3)^2+(y2-y3)^2);
L3=sqrt((x3-x1)^2+(y3-y1)^2);

dl=(L1+L2+L3)/nFixedtotal;

n1=round(L1/dl)+1;
n2=round(L2/dl)+1;
n3=nFixedtotal-n1-n2+3;

r1=linspace(0,1,n1);
r2=linspace(0,1,n2);
r3=linspace(0,1,n3);

r2=r2(2:end);
r3=r3(2:end-1);

xF1=x1+(x2-x1)*r1;
yF1=y1+(y2-y1)*r1;

xF2=x2+(x3-x2)*r2;
yF2=y2+(y3-y2)*r2;

xF3=x3+(x1-x3)*r3;
yF3=y3+(y1-y3)*r3;


Xr=rand(N,1);
Yr=rand(N,1);
[X,Y]=mapRNDintoTri(Xr,Yr,TriX,TriY);
figure(1)
clf;
fill(TriX,TriY,'c')
hold on;
scatter(xF1,yF1,40,'k','filled')
scatter(xF2,yF2,40,'k','filled')
scatter(xF3,yF3,40,'k','filled')
scatter(X,Y,30,'r','filled')





function [Xmapped,Ymapped]=mapRNDintoTri(p,q,TriX,TriY)
    
    n=length(p);
    Xmapped=zeros(size(p));
    Ymapped=zeros(size(p));
    
    Xm=0.5*(TriX(2)+TriX(3));
    Ym=0.5*(TriY(2)+TriY(3));
    
    
    
    for i=1:n
        xu=TriX(1)+p(i)*(TriX(2)-TriX(1));
        yu=TriY(1)+p(i)*(TriY(2)-TriY(1));

        xv=TriX(1)+q(i)*(TriX(3)-TriX(1));
        yv=TriY(1)+q(i)*(TriY(3)-TriY(1));

        xg=xu+xv-TriX(1);
        yg=yu+yv-TriY(1);
        
        t0=(TriX(3)-TriX(2))*(TriY(1)-TriY(2))-(TriX(1)-TriX(2))*(TriY(3)-TriY(2));
        t=(TriX(3)-TriX(2))*(yg-TriY(2))-(xg-TriX(2))*(TriY(3)-TriY(2));
        
        if sign(t0)==sign(t)
            Xmapped(i)=xg;
            Ymapped(i)=yg;
        else    % Other side
            Xmapped(i)=2*Xm-xg;
            Ymapped(i)=2*Ym-yg;
        end
    end
end


