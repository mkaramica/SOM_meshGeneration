clc;clear; clf;

k=3e5; % Number of samples, same as the number used in Figs 1 to 4

% Properties of the densed-mesh region------------------------------
a=20;    % Probability Ratio of the zoomed region to the rest of the domain;
p=0.2;  % start of step
q=0.4;  % End of step
% -------------------------------Properties of the densed-mesh region

Atot=1+(q-p)*(a-1);
x1=p/Atot;
x2=x1+a*(q-p)/Atot;
x3=x2+(1-q)/Atot;


r=rand(k,1);
y=rand(k,1);

x=NaN(size(r));

x(r<x1)=r(r<x1)*p/x1;
x(r>x1&r<x2)=p+(r(r>x1&r<x2)-x1)*(q-p)/(x2-x1);
x(r>x2)=q+(r(r>x2)-x2)*(1-q)/(1-x2);

data=[x,y];

hist3(data,'CdataMode','auto') 
xlabel('X')
ylabel('Y')
zlabel('Counter')