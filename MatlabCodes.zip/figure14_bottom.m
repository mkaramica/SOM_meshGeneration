% REV01:  Adding PDF for non-even probability function

clc;clear;clf;

% runtime: ~100 sec


s = rng;

% High density range:

xyRange=[0.4,0.6;   %   xmin,xmax
         0.6,0.8];  %   ymin,ymax
probRatio=25;


K=5e5;
xDataBase=NaN(K,1);
yDataBase=NaN(K,1);
for i=1:K
    [x,y]=pickFromPDF_2D(probRatio,xyRange);
    xDataBase(i)=x;
    yDataBase(i)=y;
end



global sigma;
global nUpdated;
N=250;
nFixed=12;
nUpdated=3*round(sqrt(N));
sigma =.0001;
g_t=0.8;

thresh=0.0005;

X = rand(N,1);
Y = rand(N,1);


xF1=zeros(nFixed,1);
yF1=linspace(0,1,nFixed)';

xF2=linspace(1/nFixed,1,nFixed-1)';
yF2=ones(nFixed-1,1);

xF3=ones(nFixed-1,1);
yF3=linspace(1-1/nFixed,0,nFixed-1)';

xF4=linspace(1-1/nFixed,0,nFixed-1)';
yF4=zeros(nFixed-1,1);

X=[X;xF1;xF2;xF3;xF4];
Y=[Y;yF1;yF2;yF3;yF4];


for k=1:K

 
%   [xg,yg] = pickFromPDF_2D(gridDensity,xyRange);

    xg=xDataBase(k);
    yg=yDataBase(k);

    [xW,yW,indxVec]= findWinners(X,Y,xg,yg);
    
    if xW(1)>xyRange(1,1) && xW(1)<xyRange(1,2) && ...
            yW(1)>xyRange(2,1) && yW(1)<xyRange(2,2)
        isInsideDenseRegion=true;
    else
        isInsideDenseRegion=false;
    end

    for i=1:nUpdated

      f_ij = calcLateralCoeff([xW(1),yW(1)],[xW(i),yW(i)]);
      
      


      if indxVec(i)<=N
          X(indxVec(i))= X(indxVec(i)) + g_t*f_ij*(xg-X(indxVec(i)));
          Y(indxVec(i))= Y(indxVec(i)) + g_t*f_ij*(yg-Y(indxVec(i)));


        %   scatter(X(indxVec(i)),Y(indxVec(i)),'sk')

        if i>1  % repel too-close neurons
            d=sqrt((X(indxVec(1))-X(indxVec(i)))^2+ ...
                (Y(indxVec(1))-Y(indxVec(i)))^2);

            if d <thresh %&& isInsideDenseRegion==false
                X(indxVec(i)) = X(indxVec(i)) + ...
                    thresh/d*(X(indxVec(i))-X(indxVec(1)));

                Y(indxVec(i)) = Y(indxVec(i)) + ...
                    thresh/d*(Y(indxVec(i))-Y(indxVec(1)));

            end

        end


      end

    end
            
            
            
    if mod(k,20000)==0
        k
    end
            

    if mod(k,100)==0
        g_t=0.999*g_t;
    end
end

i=1;
while i <=length(X)
    j=i+1;
    while j<=length(X)
        Dij=sqrt((X(i)-X(j))^2+(Y(i)-Y(j))^2);
        if (i~=j) && Dij < thresh
            X(j)=[];
            Y(j)=[];
        end
        j=j+1;
    end
    
    i=i+1;
end
        

%%

Xb=[0,0,1,1];
Yb=[0,1,1,0];
hold on
for i=1:3
    plot([Xb(i),Xb(i+1)],[Yb(i),Yb(i+1)],'r','linewidth',2);
end
plot([Xb(4),Xb(1)],[Yb(4),Yb(1)],'r','linewidth',2);

scatter(Xb,Yb,100,'ok','filled');


scatter(X,Y,'g*');
xlabel('x')
ylabel('y')
xlim([-0.1,1.1]);
ylim([-0.1,1.1]);


DT = delaunay(X,Y);

triplot(DT,X,Y);



function [xW,yW,indxVec]= findWinners(X,Y,xg,yg)
    global nUpdated;
    
    r = (X-xg).^2 + (Y-yg).^2;
    
    [sorted,indxVec]=sort(r);
    
    xW=X(indxVec(1:nUpdated));
    yW=Y(indxVec(1:nUpdated));
end


function f = calcLateralCoeff(X0,X)
    
    global sigma;
    f = NaN (size(X,1));
    for i=1: length(f)
        f(i) = exp(-0.5*norm((X(i,:)-X0))^2/sigma);
    end

end


function [x,y] = pickFromPDF_2D(rG,xyRange)
    
%     rG: Grid Ratio
    xMin=xyRange(1,1);
    xMax=xyRange(1,2);
    yMin=xyRange(2,1);
    yMax=xyRange(2,2);
    
    volTot=1+(rG-1)*(xMax-xMin)*(yMax-yMin);
    
    pMat=zeros(9,1);
    
    pMat(1)=xMin*yMin;
    pMat(2)=(xMax-xMin)*yMin;
    pMat(3)=(1-xMax)*yMin;
    pMat(4)=xMin*(yMax-yMin);
    pMat(5)=rG*(xMax-xMin)*(yMax-yMin); %***** Focused Zone *****
    pMat(6)=(1-xMax)*(yMax-yMin);
    pMat(7)=xMin*(1-yMax);
    pMat(8)=(xMax-xMin)*(1-yMax);
    pMat(9)=(1-xMax)*(1-yMax);
    
    pMat=pMat./volTot;
    pCumul=cumsum(pMat);
    pCumul=[0;pCumul];
    
    r1=rand;
    r2=rand;
    
    for i=1:9
        if r1 >= pCumul(i) && r1 <= pCumul(i+1)
            zon=i;
            
            break
        end
    end
    
    switch(zon)
        case {1,2,3}
            y1=0;
            y2=yMin;
        case {4,5,6}
            y1=yMin;
            y2=yMax;
        case {7,8,9}
            y1=yMax;
            y2=1;
    end
    
    switch(zon)
        case {1,4,7}
            x1=0;
            x2=xMin;
        case {2,5,8}
            x1=xMin;
            x2=xMax;
        case {3,6,9}
            x1=xMax;
            x2=1;
    end
    
    tMin=pCumul(zon);
    tMax=pCumul(zon+1);
    t=(r1-tMin)/(tMax-tMin);
    
    x=x1 + t*(x2-x1);
    y=y1+r2*(y2-y1);
    
    
end

