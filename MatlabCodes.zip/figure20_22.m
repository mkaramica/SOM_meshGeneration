clc;clear;
dx=0.01;
x=0:0.01:2;
pdf=NaN(size(x));
pdf(x<=0.5)=1;
pdf(x>0.5 & x<=1)=0;
pdf(x>1 & x<=1.5)=0.5+2*(x(x>1 & x<=1.5)-1);
pdf(x>1.5)=0.5;
% pdf=1+0*x;
pdf(1)=0;
pdf=pdf./sum(pdf)/dx;


cdf=cumsum(pdf);
cdf=cdf./max(cdf);

figure(1)
clf;
subplot(2,1,1)
plot(x,pdf,'b','linewidth',2)
xlabel('X')
ylabel('PDF')

subplot(2,1,2)
plot(x,cdf,'r','linewidth',2)
xlabel('X')
ylabel('CDF')


k=1000000;

[X,r]=randomGen(x,pdf,k);

figure(2)
clf;
histogram(X,length(x))

figure(3)
scatter(r,X)

function [x,randSet]=randomGen(xRange,pdf,N)
    if nargin==2
        N=1;
    end
    pdf(1)=0;
    cdf=cumsum(pdf);
    cdf=cdf./max(cdf);
    
    x=NaN(N,1);
    randSet=NaN(N,1);
    
    for i=1:N
    
        r=rand;
        randSet(i)=r;

        iLeft=1;
        iRight=length(xRange);

        while iRight-iLeft>1
            iMid=round(0.5*(iLeft+iRight));

            if cdf(iMid)>r
                iRight=iMid;
            else
                iLeft=iMid;
            end
            
        end

        
        x(i)=xRange(iLeft)+ ...
        (r-cdf(iLeft))/(cdf(iRight)-cdf(iLeft))*...
            (xRange(iRight)-xRange(iLeft));
    end

end

