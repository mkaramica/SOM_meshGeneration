clc;clear;clf;

k=3e5; % Number of samples, same as the number used in Figs 1 to 4

X=rand(k,1);

histogram(X,100);
xlabel('X')
ylabel('Counter')





