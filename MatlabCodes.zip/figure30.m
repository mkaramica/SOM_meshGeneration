clc;clear;clf;

% runtime: ~15 minutes

nBoundaryNodes=60;

XY=load( 'domain_notSorted.txt');
[X,Y]=sortDomainBoundary(XY);

X=[X;X(1);];
Y=[Y;Y(1);];

S=zeros(size(X));
S(2:end)=sqrt( (X(2:end)-X(1:end-1)).^2 + (Y(2:end)-Y(1:end-1)).^2);

S=cumsum(S');
S=S./max(S);
XY=[X';Y'];
pp = spline(S,XY);
xy = ppval(pp, linspace(0,1,1001));

Xb=xy(1,:)';
Yb=xy(2,:)';

sBoundaryNodes=linspace(0,1,nBoundaryNodes+1);
sBoundaryNodes=sBoundaryNodes(2:end);

XY_bN=ppval(pp, sBoundaryNodes);


N=3e6;
x=rand(N,1);
y=rand(N,1);

isInside=checkInsideOrOutside(Xb,Yb,x,y);

x=x(isInside);
y=y(isInside);
data=[x,y];


hist3(data, 'Nbins', [80,80],'FaceColor','interp');
% hist3(data,'CDataMode',[80,80],'FaceColor','interp')

xlabel('X')
ylabel('Y')
zlabel('count')

%--------Activate this line to use the created PDF for fig. 31 & 32
% save rndDomain data;
%--------Activate this line to use the created PDF for fig. 31 & 32

function isInside=checkInsideOrOutside(Xb,Yb,xp,yp)
    isInside=true(size(xp));
    for j=1:length(xp)
        t=0;
        for i=1:length(Xb)
            v1=[Xb(i)-xp(j),Yb(i)-yp(j)];
            if i<length(Xb)
                v2=[Xb(i+1)-xp(j),Yb(i+1)-yp(j)];
            else
                v2=[Xb(1)-xp(j),Yb(1)-yp(j)];
            end

            t= t+ (v1(1)*v2(2)-v1(2)*v2(1))/(norm(v1)*norm(v2));
        end


        if abs(t-2*pi)<abs(t)
            isInside(j)=true;
        else
            isInside(j)=false;
        end
        if mod(j,10000)==0
            j
        end
    end
        

end


function [X,Y]=sortDomainBoundary(XY_in)
    Xin=XY_in(:,1);
    Yin=XY_in(:,2);
    
    X=NaN(size(Xin));
    Y=NaN(size(Xin));
    
    X(1)=Xin(1);
    Y(1)=Yin(1);

    Xin(1)=[];
    Yin(1)=[];

    i=1;

    while ~isempty(Xin)>0
        d=sqrt( (Xin-X(i)).^2 + (Yin-Y(i)).^2  );
        [~,indx]=min(d);

        X(i+1)=Xin(indx);
        Y(i+1)=Yin(indx);
        Xin(indx)=[];
        Yin(indx)=[];

        i=i+1;
    end
    
end
