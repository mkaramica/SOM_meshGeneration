clc;clear; clf;
global sigma;
global nUpdated;

% runtime: ~80 sec

ss=rng;

x1=0.1;x2=0.7;x3=0.35;
y1=0.3;y2=0.2;y3=0.9;
domainArea = 0.5 *(-y2*x3 + y1*(-x2 + x3) + x1*(y2 - y3) + x2*y3);
% x1=0.0;x2=1;x3=0.5;
% y1=0.0;y2=0.0;y3=sqrt(3)/2;


TriX=[x1,x2,x3];
TriY=[y1,y2,y3];


N=180;
nFixedtotal=45;
nUpdated=3*round(sqrt(N));
sigma =.0002;
g_t=0.8;

thresh=0.02;
threshRepel=thresh;


L1=sqrt((x1-x2)^2+(y1-y2)^2);
L2=sqrt((x2-x3)^2+(y2-y3)^2);
L3=sqrt((x3-x1)^2+(y3-y1)^2);

dl=(L1+L2+L3)/nFixedtotal;

n1=round(L1/dl)+1;
n2=round(L2/dl)+1;
n3=nFixedtotal-n1-n2+3;

r1=linspace(0,1,n1);
r2=linspace(0,1,n2);
r3=linspace(0,1,n3);

r2=r2(2:end);
r3=r3(2:end-1);

xF1=x1+(x2-x1)*r1;
yF1=y1+(y2-y1)*r1;

xF2=x2+(x3-x2)*r2;
yF2=y2+(y3-y2)*r2;

xF3=x3+(x1-x3)*r3;
yF3=y3+(y1-y3)*r3;


Xr=rand(N,1);
Yr=rand(N,1);
[X,Y]=mapRNDintoTri(Xr,Yr,TriX,TriY);
figure(1)
clf;
fill(TriX,TriY,'y')
hold on;
scatter(xF1,yF1,40,'k','filled')
scatter(xF2,yF2,40,'k','filled')
scatter(xF3,yF3,40,'k','filled')
scatter(X,Y,30,'r','filled')


X=[X;xF1';xF2';xF3'];
Y=[Y;yF1';yF2';yF3'];


nItr=500000;

rndVec1=rand(nItr,1);
rndVec2=rand(nItr,1);

[XgVec,YgVec]=mapRNDintoTri(rndVec1,rndVec2,TriX,TriY);


for k=1:nItr
 
    xg=XgVec(k);yg=YgVec(k);

    [xW,yW,indxVec]= findWinners(X,Y,xg,yg);

    for i=1:nUpdated

      f_ij = calcLateralCoeff([xW(1),yW(1)],[xW(i),yW(i)]);

      if indxVec(i)<=N



          X(indxVec(i))= X(indxVec(i)) + g_t*f_ij*(xg-X(indxVec(i)));
          Y(indxVec(i))= Y(indxVec(i)) + g_t*f_ij*(yg-Y(indxVec(i)));

        %   scatter(X(indxVec(i)),Y(indxVec(i)),'sk')

        if i>1  % repel too-close neurons
            d=sqrt((X(indxVec(1))-X(indxVec(i)))^2+ ...
                (Y(indxVec(1))-Y(indxVec(i)))^2);

            if d <threshRepel
                xUpdate = X(indxVec(i)) + ...
                    threshRepel/d*(X(indxVec(i))-X(indxVec(1)));

                yUpdate = Y(indxVec(i)) + ...
                    threshRepel/d*(Y(indxVec(i))-Y(indxVec(1)));

               s = 1/(2*domainArea)*(y1*x3 - x1*y3 + ...
                   (y3 - y1)*xUpdate + (x1 - x3)*yUpdate);
               t = 1/(2*domainArea)*(x1*y2 - y1*x2 + ...
                   (y1 - y2)*xUpdate + (x2 - x1)*yUpdate);
               
               X(indxVec(i))=xUpdate;
               Y(indxVec(i))=yUpdate;

                % Check if the point is inside:************************

%                 if s>=0 && t>=0 && s+t<=1
%                     X(indxVec(i))=xUpdate;
%                     Y(indxVec(i))=yUpdate;
% %                 elseif s<0 && t <0
% %                     X(indxVec(i))=x1+threshRepel;
% %                     Y(indxVec(i))=y1+threshRepel;
%                 else
%                     if s<0
%                         xA=x1;
%                         yA=y1;
%                         xB=x3;
%                         yB=y3;
%                     elseif t<0
%                         xA=x1;
%                         yA=y1;
%                         xB=x2;
%                         yB=y2;
%                     else
%                         xA=x2;
%                         yA=y2;
%                         xB=x3;
%                         yB=y3;
%                     end
%                     
%                     m1=(yB-yA)/(xB-xA);
%                     m2=(Y(indxVec(i))-yUpdate)/(X(indxVec(i))-xUpdate);
%                     xp=(m1*xUpdate-m2*xA+yA-yUpdate)/(m1-m2);
%                     yp=m1*(xp-xUpdate)+yUpdate;
%                     X(indxVec(i))=xp;
%                     Y(indxVec(i))=yp;
%                     
%                 end                          %**************************
            end

        end

      end

    end
            
%     X(N+1:end)=[xF1';xF2';xF3'];
%     Y(N+1:end)=[yF1';yF2';yF3'];

    if mod(k,100)==0
        g_t=0.9992*g_t;
    end
    
    if mod(k,5000)==0 
        k
    end
end

Xin=X(1:N);
Xb=X(N+1:end);
Yin=Y(1:N);
Yb=Y(N+1:end);


%%

s = 1/(2*domainArea)*(y1*x3 - x1*y3 + ...
       (y3 - y1)*Xin + (x1 - x3)*Yin);
t = 1/(2*domainArea)*(x1*y2 - y1*x2 + ...
   (y1 - y2)*Xin + (x2 - x1)*Yin);

Xin(s<0|t<0|s+t>1)=[];
Yin(s<0|t<0|s+t>1)=[];

% i=1;
% while i <= length(Xin)
%     s = 1/(2*domainArea)*(y1*x3 - x1*y3 + ...
%        (y3 - y1)*Xin(i) + (x1 - x3)*Yin(i));
%     t = 1/(2*domainArea)*(x1*y2 - y1*x2 + ...
%        (y1 - y2)*Xin(i) + (x2 - x1)*Yin(i));
%    
%     if s<0 || t<0 || s+t>1
%        Xin(i)=[];
%        Yin(i)=[];
%        disp('!')
%     end
%    
%     i=i+1;
% end

%%

for i=1:nFixedtotal
   j=1;
   while j <=length(Xin)
       Dij=sqrt((Xin(j)-Xb(i))^2+(Yin(j)-Yb(i))^2);
       if Dij < thresh
           Xin(j)=[];
           Yin(j)=[];
       end
       
       j=j+1;
   end
   
    
end

i=1;
while i <=length(Xin)
    j=i+1;
    while j<=length(Xin)
        Dij=sqrt((Xin(i)-Xin(j))^2+(Yin(i)-Yin(j))^2);
        if Dij < thresh
            Xin(j)=[];
            Yin(j)=[];
        end
        j=j+1;
    end
    
    i=i+1;
end

X=[Xin;Xb];
Y=[Yin;Yb];
 %%       


DijAVG=0;
n=0;
for i=1:length(X)
    Dlist=sort(sqrt((X(i)-X).^2+(Y(i)-Y).^2));
    DijAVG=DijAVG + Dlist(2)+Dlist(3)+Dlist(4);
end

DijAVG=DijAVG/(3*length(X));



%%


figure(2)
clf;
fill(TriX,TriY,'y')
hold on;

scatter(X,Y,30,'ro','filled');
xlabel('X')
ylabel('Y')
xlim([0.1,0.7])
ylim([0.2,0.95])


DT = delaunay(X,Y);
figure(2);

triplot(DT,X,Y,'b');


function [xW,yW,indxVec]= findWinners(X,Y,xg,yg)
    global nUpdated;
    
    r = (X-xg).^2 + (Y-yg).^2;
    
    [sorted,indxVec]=sort(r);
    
    xW=X(indxVec(1:nUpdated));
    yW=Y(indxVec(1:nUpdated));
end


function f = calcLateralCoeff(X0,X)
    
    global sigma;
    f = NaN (size(X,1));
    for i=1: length(f)
        f(i) = exp(-0.5*norm((X(i,:)-X0))^2/sigma);
    end

end


function [Xmapped,Ymapped]=mapRNDintoTri(p,q,TriX,TriY)
    
    n=length(p);
    Xmapped=zeros(size(p));
    Ymapped=zeros(size(p));
    
    Xm=0.5*(TriX(2)+TriX(3));
    Ym=0.5*(TriY(2)+TriY(3));
    
    
    
    for i=1:n
        xu=TriX(1)+p(i)*(TriX(2)-TriX(1));
        yu=TriY(1)+p(i)*(TriY(2)-TriY(1));

        xv=TriX(1)+q(i)*(TriX(3)-TriX(1));
        yv=TriY(1)+q(i)*(TriY(3)-TriY(1));

        xg=xu+xv-TriX(1);
        yg=yu+yv-TriY(1);
        
        t0=(TriX(3)-TriX(2))*(TriY(1)-TriY(2))-(TriX(1)-TriX(2))*(TriY(3)-TriY(2));
        t=(TriX(3)-TriX(2))*(yg-TriY(2))-(xg-TriX(2))*(TriY(3)-TriY(2));
        
        if sign(t0)==sign(t)
            Xmapped(i)=xg;
            Ymapped(i)=yg;
        else    % Other side
            Xmapped(i)=2*Xm-xg;
            Ymapped(i)=2*Ym-yg;
        end
    end
end




