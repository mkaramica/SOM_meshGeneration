xyRange=[0.4,0.6;
         0.6,0.8];
probRatio=25;
k=3e5;
X=NaN(k,1);
Y=NaN(k,1);

for i=1:k
    [x,y]=pickFromPDF_2D(probRatio,xyRange);
    X(i)=x;
    Y(i)=y;
end

data=[X,Y];
hist3(data,'CdataMode','auto') 
xlabel('X')
ylabel('Y')
zlabel('Counter')


function [x,y] = pickFromPDF_2D(rG,xyRange)
    
%     rG: Grid Ratio
    xMin=xyRange(1,1);
    xMax=xyRange(1,2);
    yMin=xyRange(2,1);
    yMax=xyRange(2,2);
    
    volTot=1+(rG-1)*(xMax-xMin)*(yMax-yMin);
    
    pMat=zeros(9,1);
    
    pMat(1)=xMin*yMin;
    pMat(2)=(xMax-xMin)*yMin;
    pMat(3)=(1-xMax)*yMin;
    pMat(4)=xMin*(yMax-yMin);
    pMat(5)=rG*(xMax-xMin)*(yMax-yMin); %***** Focused Zone *****
    pMat(6)=(1-xMax)*(yMax-yMin);
    pMat(7)=xMin*(1-yMax);
    pMat(8)=(xMax-xMin)*(1-yMax);
    pMat(9)=(1-xMax)*(1-yMax);
    
    pMat=pMat./volTot;
    pCumul=cumsum(pMat);
    pCumul=[0;pCumul];
    
    r1=rand;
    r2=rand;
    
    for i=1:9
        if r1 >= pCumul(i) && r1 <= pCumul(i+1)
            zon=i;
            
            break
        end
    end
    
    switch(zon)
        case {1,2,3}
            y1=0;
            y2=yMin;
        case {4,5,6}
            y1=yMin;
            y2=yMax;
        case {7,8,9}
            y1=yMax;
            y2=1;
    end
    
    switch(zon)
        case {1,4,7}
            x1=0;
            x2=xMin;
        case {2,5,8}
            x1=xMin;
            x2=xMax;
        case {3,6,9}
            x1=xMax;
            x2=1;
    end
    
    tMin=pCumul(zon);
    tMax=pCumul(zon+1);
    t=(r1-tMin)/(tMax-tMin);
    
    x=x1 + t*(x2-x1);
    y=y1+r2*(y2-y1);
    
    
end

