clc;clear;clf;
k=5e5; % Number of samples

% Properties of the densed-mesh region for x------------------------------
a_x=5;    % Probability Ratio of the zoomed region to the rest of the domain;
p_x=0.4;  % start of step
q_x=0.6;  % End of step
% -------------------------------Properties of the densed-mesh region for x


% Properties of the densed-mesh region for y------------------------------
a_y=5;    % Probability Ratio of the zoomed region to the rest of the domain;
p_y=0.6;  % start of step
q_y=0.8;  % End of step
% -------------------------------Properties of the densed-mesh region for y



X=createStepProbability(k,[a_x,p_x,q_x]);
Y=createStepProbability(k,[a_y,p_y,q_y]);



subplot(2,1,1)
histogram(X,100);
xlabel('X')
ylabel('Counter')
subplot(2,1,2)
histogram(Y,100);
xlabel('Y')
ylabel('Counter')



function X=createStepProbability(N,param)

    X=NaN(N,1);
    
    a=param(1);
    p=param(2);
    q=param(3);
    
    
    Atot=1+(q-p)*(a-1);

    x1=p/Atot;
    x2=x1+a*(q-p)/Atot;
    x3=x2+(1-q)/Atot;
    
    for i=1:N
        r=rand;
    
        if r<x1
            X(i)=r*p/x1;
        elseif r<x2
            X(i)=p+(r-x1)*(q-p)/(x2-x1);
        else
            X(i)=q+(r-x2)*(1-q)/(1-x2);
        end
    end
    
    


end

