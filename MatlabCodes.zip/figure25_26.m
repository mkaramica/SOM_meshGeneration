clc;clear;

% runtime: ~120 sec

x=0:0.01:2;
y=0:0.1:3;

[xx,yy]=meshgrid(x,y);

pdf2D=xx+2;
pdf2D(xx>1)=0;
pdf2D(yy>2)=5.5-yy(yy>2);
pdf2D(abs(xx-1.5)<0.2 & abs(yy-1)<0.3)=4;
pdf2D(xx==x(1) | xx==x(end))=0;
pdf2D(yy==y(1) | yy==y(end))=0;

figure(1)
clf;
mesh(xx,yy,pdf2D);
xlabel('X')
ylabel('Y')
zlabel('PDF')




N=1e7;
[X,Y]=generateRandfromPDF2D(x,y,pdf2D,N);
% load Xvector.mat;
% load Yvector.mat;

data=[X,Y];
figure(2)
clf;
hist3(data, 'Nbins', [100,100]);
xlabel('X')
ylabel('Y')
zlabel('count')


function [X,Y]=generateRandfromPDF2D(xRange,yRange,pdf2D,N)
    
    X=NaN(N,1);
    Y=NaN(N,1);
    i=0;
    
    while i<N
        r1=rand;
        r2=rand;
        r3=rand;

        x=xRange(1)+r1*(xRange(end)-xRange(1));
        y=yRange(1)+r2*(yRange(end)-yRange(1));
        z=r3*max(max(pdf2D));
        
        indxX=find(xRange>x,1);
        indxY=find(yRange>y,1);
        
        fSW=pdf2D(indxY-1,indxX-1);
        fNW=pdf2D(indxY,indxX-1);
        fSE=pdf2D(indxY-1,indxX);
        fNE=pdf2D(indxY,indxX);
        
        fW=fSW + (y-yRange(indxY-1)) /(yRange(indxY)-yRange(indxY-1)) ...
            *(fNW-fSW);
        
        fE=fSE + (y-yRange(indxY-1)) /(yRange(indxY)-yRange(indxY-1)) ...
            *(fNE-fSE);
        
        fG=fW + (x-xRange(indxX-1)) /(xRange(indxX)-xRange(indxX-1)) ...
            *(fE-fW);
        
        fG=pdf2D(indxY,indxX);
        
        if z <fG
            i=i+1;
            X(i)=x;
            Y(i)=y;
        end
        
        
    end
    
    
    
    
    
    

    
end