clc;clear;

xmin=0.3;xmax=0.6;
ymin=0.5;ymax=0.8;
a=2;

x=0:.01:1;
y=0:.01:1;



[X,Y]=meshgrid(x,y);

Z=ones(size(X));

region=X>xmin&X<xmax&Y>ymin&Y<ymax;
boundary=X==0|X==1|Y==0|Y==1;



Z(region)=2;
Z(boundary)=0;

figure(1)
clf;
mesh(X,Y,Z)
xlabel('X')
ylabel('Y')
zlabel('Z')


figure(2)
hold on;
x=[0,xmin,xmax,1];
y=[0,ymin,ymax,1];

for i=1:4
    plot([0,1],[y(i),y(i)],'b','linewidth',2)
    plot([x(i),x(i)],[0,1],'b','linewidth',2)
end

xticks([0 1])
yticks([0 1])
xlabel('X')
ylabel('Y')

